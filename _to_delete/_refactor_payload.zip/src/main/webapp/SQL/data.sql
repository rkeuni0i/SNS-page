USE mysns;

-- 아래 계정들의 로그인 비밀번호는 모두 test1234! 입니다.
INSERT INTO user(id, password_hash, salt, name) VALUES
  ('kim@abc.com', 'hjJFB443vg/r8H3dyHyf901enDTlpveL8NTbZ1phH9c=', 'dJxNOG4lL0VPXRiOTzvXog==', '김시민'),
  ('lee@abc.com', 'Cu3JGFJH9dOdtgBQy5QIe6EUoUmSX4pe0yXSNeb4xlM=', 'FRsZfeVVHrC8i1aB7NOVLA==', '이순신'),
  ('kwon@abc.com', 'N6oekE1VH3K8cVc+G/pUVtCQ5dnv68LUZZYxgkbnz30=', 'q9ZPOL8Am/b2cEeqXlE01g==', '권율');

INSERT INTO feed(id, content) VALUES
  ('kim@abc.com', 'Hello'),
  ('kwon@abc.com', 'Aloha');
